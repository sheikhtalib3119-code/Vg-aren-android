# VG Aren Android Project

VG Aren — Free Fire Team VG Guild Test app prototype.

## Build
Open this folder in Android Studio and choose **Build > Generate Signed Bundle / APK > Android App Bundle**.

Application ID: `com.vgaren.app`
Version: `1.0` (versionCode 1)

The current build wraps the existing VG Aren HTML prototype inside an Android WebView. The registration/admin data is not yet connected to an online backend; Firebase/Supabase can be added later for real multi-device registrations, admin moderation, schedules and results.

Footer/credit: Powered by Sheikh Talib.
